module com.studentprofile.studentprofile {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.studentprofile.studentprofile to javafx.fxml;
    exports com.studentprofile.studentprofile;
}